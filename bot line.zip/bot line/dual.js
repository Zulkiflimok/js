const thrift = require('thrift-http');
const LineService = require('./LibJS/NewTalkService');
const { DeleteOtherFromChatRequest, GetChatsRequest } = require('./LibJS/NewTalkService_types');

// --- SET MANUAL ---
let gid = "GROUP_ID_HERE";      // ganti dengan ID grup
let token = "BOT_TOKEN_HERE";   // ganti dengan token bot
let botMid = "BOT_MID_HERE";    // MID bot sendiri agar tidak ter-kick
// ----------------

let client = null;

// Setup client LINE
function setClient() {
  const connection = thrift.createHttpConnection('gw.line.naver.jp', 443, {
    protocol: thrift.TCompactProtocol,
    transport: thrift.TBufferedTransport,
    headers: {
      'User-Agent': 'Line/8.3.0',
      'X-Line-Application': 'DESKTOPWIN\t8.6.0\tWINDOWS\t10.0',
      'X-Line-Access': token
    },
    path: '/S4',
    https: true
  });

  connection.on('error', err => console.error('Connection error:', err));
  client = thrift.createHttpClient(LineService, connection);
}

// Ambil semua member grup
async function getMembers() {
  const req = new GetChatsRequest();
  req.chatMids = [gid];
  req.withMembers = true;
  try {
    const result = await client.getChats(req);
    return result.chats[0]?.extra?.groupExtra?.memberMids || [];
  } catch (e) {
    console.error('Gagal ambil member:', e);
    return [];
  }
}

// Kick semua member kecuali bot
async function kickAll() {
  const members = await getMembers();
  if (!members.length) {
    console.log('Tidak ada member untuk dikick.');
    return;
  }

  for (const mid of members) {
    if (mid === botMid) continue; // Jangan kick bot sendiri
    const req = new DeleteOtherFromChatRequest();
    req.reqSeq = 0;
    req.chatMid = gid;
    req.targetUserMids = [mid];
    try {
      await client.deleteOtherFromChat(req);
      console.log(`Kick member: ${mid}`);
    } catch (e) {
      console.error(`Gagal kick ${mid}:`, e);
    }
  }

  console.log('Proses kick selesai!');
}

// Main
(async () => {
  setClient();
  await kickAll();
})();