# -*- coding: utf-8 -*-
from akad.ttypes import Message
from .auth import Auth
from .models import Models
from .talk import Talk
from .call import Call
from .shop import Shop
from .liff import Liff

class LINE(Auth, Models, Talk, Call, Shop, Liff):

    def __init__(self, idOrAuthToken=None, passwd=None, **kwargs):
        self.certificate = kwargs.pop('certificate', None)
        self.systemName = kwargs.pop('systemName', None)
        self.appType = kwargs.pop('appType', None)
        self.appName = kwargs.pop('appName', None)
        self.showQr = kwargs.pop('showQr', False)
        self.channelId = kwargs.pop('channelId', None)
        self.keepLoggedIn = kwargs.pop('keepLoggedIn', True)
        self.customThrift = kwargs.pop('customThrift', False)
        
        # Login
        Auth.__init__(self)
        if not (idOrAuthToken or passwd):
            self.loginWithQrCode()
        elif idOrAuthToken and passwd:
            self.loginWithCredential(idOrAuthToken, passwd)
        elif idOrAuthToken and not passwd:
            self.loginWithAuthToken(idOrAuthToken)
        
        # Init modul yang bisa dipakai
        self.__initAll()

    def __initAll(self):
        # Ambil profil
        try:
            self.profile = self.talk.getProfile()
        except Exception as e:
            print("⚠️ Gagal ambil profil:", e)
            self.profile = None

        # Generate user ticket
        try:
            self.userTicket = self.generateUserTicket()
        except Exception as e:
            print("⚠️ Gagal generate userTicket:", e)
            self.userTicket = None

        # Inisialisasi modul lain
        try: Models.__init__(self)
        except Exception as e: print("⚠️ Models init error:", e)
        try: Talk.__init__(self)
        except Exception as e: print("⚠️ Talk init error:", e)
        try: Call.__init__(self)
        except Exception as e: print("⚠️ Call init error:", e)
        try: Shop.__init__(self)
        except Exception as e: print("⚠️ Shop init error:", e)
        try: Liff.__init__(self)
        except Exception as e: print("⚠️ Liff init error:", e)