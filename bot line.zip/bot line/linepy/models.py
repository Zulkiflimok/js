# -*- coding: utf-8 -*-
from datetime import datetime
from .object import Object
from random import randint, choice, seed

import json
import shutil
import time
import os
import base64
import tempfile
import re
import random

class Models(Object):
        
    def __init__(self):
        super().__init__()

    """Text Logging"""

    def log(self, text):
        print(f"[{datetime.now()}] {text}")

    """File Handling"""

    def saveFile(self, path, raw):
        with open(path, 'wb') as f:
            shutil.copyfileobj(raw, f)

    def deleteFile(self, path):
        if os.path.exists(path):
            os.remove(path)
            return True
        return False

    """ID & Temp file"""

    def genObjectId(self):
        seed(os.urandom(1024))
        return ''.join(choice("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789") for _ in range(32))
        
    def genTempFile(self, returnAs='path'):
        if returnAs not in ['file', 'path']:
            raise Exception('Invalid returnAs value')
        fName = f"linepy-{int(time.time())}-{randint(0, 9)}.bin"
        fPath = tempfile.gettempdir()
        return fName if returnAs == 'file' else os.path.join(fPath, fName)

    """Download Files"""

    def downloadFileURL(self, fileUrl, returnAs='path', saveAs='', headers=None):
        if returnAs not in ['path','bool','bin']:
            raise Exception('Invalid returnAs value')
        if not saveAs:
            saveAs = self.genTempFile()
        r = self.server.getContent(fileUrl, headers=headers)
        if r.status_code != 404:
            self.saveFile(saveAs, r.raw)
            if returnAs == 'path':
                return saveAs
            elif returnAs == 'bool':
                return True
            elif returnAs == 'bin':
                return r.raw
        else:
            raise Exception('Download file failure.')

    """URL Validation"""

    def validateURL(self, url, returnAs='bool'):
        if returnAs not in ['bool', 're']:
            raise Exception('Invalid returnAs value')
        result = re.match(self.server.URL_REGEX, url)
        return bool(result) if returnAs == 'bool' else result

    """Find IDs"""

    def findMids(self, text):
        return self.server.MID_REGEX.findall(text)

    def findGids(self, text):
        return self.server.GID_REGEX.findall(text)

    def findRids(self, text):
        return self.server.RID_REGEX.findall(text)

    def findAllIds(self, text):
        return self.server.ALLIDS_REGEX.findall(text)

    """OBS Parameters"""

    def genOBSParams(self, newList, returnAs='json'):
        oldList = {'name': self.genTempFile('file'), 'ver': '1.0'}
        if returnAs not in ['json','b64','default']:
            raise Exception('Invalid parameter returnAs')

        if 'name' in newList and not newList['name']:
            newList['name'] = oldList['name']
        oldList.update(newList)

        if 'range' in oldList:
            new_range = f"bytes 0-{oldList['range']-1}/{oldList['range']}"
            oldList['range'] = new_range

        if returnAs == 'json':
            return json.dumps(oldList)
        elif returnAs == 'b64':
            return base64.b64encode(json.dumps(oldList).encode('utf-8'))
        return oldList

    """SelfBot PIN Handler"""

    def waitPIN(self, pinCode, waitSeconds=120):
        """Fungsi ini bisa dipanggil dari zul.py untuk menunggu PIN"""
        self.log(f"Input PIN SelfBot '{pinCode}' dalam {waitSeconds} detik...")
        start = time.time()
        while time.time() - start < waitSeconds:
            time.sleep(1)
        self.log("Waktu tunggu PIN selesai.")